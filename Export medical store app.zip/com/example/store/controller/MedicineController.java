package com.example.store.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.store.pojo.Medicine;
import com.example.store.repository.MedicineRepository;
import com.example.store.response.MedicineResponse;

@Controller
public class MedicineController {
	
	@GetMapping("/addMedicines")
	public String addMedicine(Model model) {
		
		model.addAttribute("message", "\nPlease add medicines here");
		
		return "addMedicine";
	}
	
	@Autowired
	private MedicineRepository medicineRepository;
	
	@PostMapping(path = "/addMedicines")
	public String addRequiredMedicines(Medicine medicineData, Model model) {
		
		Medicine medicine = new Medicine();
		medicine.setName(medicineData.getName());
		medicine.setType(medicineData.getType());
		medicine.setUnitPrice(medicineData.getUnitPrice());
		medicine.setQuantityInStock(medicineData.getQuantityInStock());
		
		medicineRepository.save(medicine);
		model.addAttribute("message", "\nThe medicine " +medicine.getName()+" has been added successfully!");
		
		return "addMedicine";
	}
	
	@GetMapping("/all")
	public String getAllMedicines(Model model) {
		
	    Iterable<Medicine> medicine = medicineRepository.findAll();
	    
	    model.addAttribute("medicine", medicine);
	    
	    return "Medicinelist";

	  } 
	// new API for mobile application without thymeleaf
	// @GetMapping("/api/all") --> for postman testing ---> for handling web as well as mobile application
	
	@GetMapping("/select-by-id/{id}")
	public String getSpecificMedicineById (@PathVariable Integer id, Model model) {
		
		// Optional object is used to represent null with absent value. 
		// here findById is a built in method within the crudRepository which is being extended by the user-defined "medicineRepository" interface
		Optional<Medicine> medicineData = medicineRepository.findById(id);
		
		Medicine medicineDetails = medicineData.get();
		
		model.addAttribute("medicineDetails", medicineDetails);
		
		return "medicinedetails";
				
	}
	
	//for rendering html page for recieving the medicine details, note that the previous old deatils of the medicine will be there which we can edit and then save the updated record
		@GetMapping("/update/{id}")
		public String updateMedicine(@PathVariable(value = "id") Integer id, Model model) {
			
			Optional<Medicine> optionalMedicineDetails = medicineRepository.findById(id);
			Medicine medicineDetails = optionalMedicineDetails.get();
			
			model.addAttribute("id", id);
			model.addAttribute("medicineDetails", medicineDetails);
			
			return "updateMedicine";
		}
		
		@PostMapping("/update/{id}")
		public String updateMedicine(@PathVariable(value="id") Integer id, @RequestParam String name, @RequestParam String type, @RequestParam int unitPrice, @RequestParam int quantityInStock, Model model) {
			
			Optional<Medicine> optionalMedicineDetails = medicineRepository.findById(id);
			Medicine medicineDetails = optionalMedicineDetails.get();
			
			medicineDetails.setName(name);
			medicineDetails.setType(type);
			medicineDetails.setUnitPrice(unitPrice);
			medicineDetails.setQuantityInStock(quantityInStock);
			medicineRepository.save(medicineDetails);
			
			return "redirect:/all";
		}
		
		@GetMapping("/delete/{id}")
		public String deleteMedicine(@PathVariable Integer id, Model model) {
			
			Optional<Medicine> optionalMedicineDetails = medicineRepository.findById(id);
			Medicine medicineDetails = optionalMedicineDetails.get();
			model.addAttribute("id", id);
			model.addAttribute("medicineDetails", medicineDetails);
			
			return "delete";
		}
		
		@PostMapping("/delete/{id}")
		public String deleteMedicines(@PathVariable Integer id, Model model) {
			
			try {
				Optional<Medicine> optionalMedicineDetails = medicineRepository.findById(id);
				Medicine medicineDetails = optionalMedicineDetails.get();
				medicineRepository.delete(medicineDetails);
				model.addAttribute("message", "\nThe medicine " +medicineDetails.getName()+" has been deleted successfully!");

				//return "redirect:/all";
			
				//return "delete";
			}
			
			catch(Exception e) {
				
				return "error in deleting the medicine";
					
			}
			return "delete";
		}
		
		/*@PostMapping("/delete/{id}")
		public String deleteUser(@RequestParam(name = "id", required = false) Integer id, Model model) {
			if(id != null) {
				Optional<Medicine> medicineDetails = medicineRepository.findById(id);
				medicineRepository.delete(medicineDetails);
				return "redirect:/all";
			}
			
			return "delete";
		}*/
		
		
		/*@GetMapping("/get")
		public MedicineResponse getMedicine() {
			
			MedicineResponse medicineResponse = new MedicineResponse(1, "cough", "Syrup");
			return medicineResponse;
		}*/
		
		@GetMapping("/search")
		 public String searchMedicine(Medicine medicine, Model model, String keyword) {
		  if(keyword!=null) {
		   List<Medicine> list = getByKeyword(keyword);
		   model.addAttribute("list", list);
		  }else {
		  return "redirect:/all";
		  }
		  return "index";
		 }
		
		 public List<Medicine> getByKeyword(String keyword){
			 
			  return medicineRepository.findByKeyword(keyword);
	     }
		 
		 /*@PostMapping(path = "/search")
			public String SearchMedicine(Medicine medicineData, Model model, String keyword) {
				
				Medicine medicine = new Medicine();
				medicine.setName(medicineData.getName());
				medicine.setType(medicineData.getType());
				medicine.setUnitPrice(medicineData.getUnitPrice());
				medicine.setQuantityInStock(medicineData.getQuantityInStock());
				
				medicineRepository.save(medicine);
				model.addAttribute("message", "\nThe medicine " +medicine.getName()+" has been added successfully!");
				
				return "addMedicine";*/
		
}
