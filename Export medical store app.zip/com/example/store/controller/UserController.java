package com.example.store.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.store.pojo.User;
import com.example.store.repository.UserRepository;

@Controller
public class UserController {
	
	// doesn't require post mapping
	@RequestMapping("/signup")
	public String signUpAction(Model model) {
		
		model.addAttribute("message", "Sign Up");
		
		return "signup";
	}
	
	@Autowired
	private UserRepository userRepository;
	
	@PostMapping(path = "/signup")
	public String signupActionProcess(User userData, Model model) {
		
		User user = new User();
		user.setUserName(userData.getUserName());
		user.setPassword(userData.getPassword());
		user.setEmail(userData.getEmail());
		
		userRepository.save(user);
		model.addAttribute("message", "\nThe user " +user.getUserName()+" has signed up successfully!!");
		
		return "signup";
	}
		

}
