package com.example.store.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.store.pojo.Medicine;

@Repository
public interface MedicineRepository extends CrudRepository<Medicine, Integer>{
	
	// for searching the medicine with its name
	@Query(value = "select * from medicines m where m.name like %:keyword%", nativeQuery = true)
	 List<Medicine> findByKeyword(@Param("keyword") String keyword);
	

}
