package com.example.store.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


import com.example.store.pojo.User;

@Repository
public interface UserRepository extends CrudRepository<User, Integer> {
	

}
